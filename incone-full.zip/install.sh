(cd mf && make && make install)
(cd rlzrs && make && make install)
(cd metric && make && make install)
(cd incone && make && make install)
